 function clickPrincipal(){
    return (
        <>{alert('olá mundo')}</>
    );
}

export default clickPrincipal;