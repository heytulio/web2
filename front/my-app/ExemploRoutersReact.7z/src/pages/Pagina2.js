import {  Link } from "react-router-dom";

export default function Pagina2()
{
    return (
        <div>
            <Link to="/Menu">Menu</Link>
         </div>
    );  
}